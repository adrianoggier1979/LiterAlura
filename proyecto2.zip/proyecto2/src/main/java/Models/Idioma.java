package Models;

public enum Idioma {
    ES, EN, FR, PT
}
